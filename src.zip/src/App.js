import React, { useRef, useState } from "react";

const LiveVideoFeed = () => {
  const videoRef = useRef(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [error, setError] = useState("");

  const startVideo = async () => {
    setError("");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      videoRef.current.srcObject = stream;
      videoRef.current.play();
      setIsStreaming(true);
    } catch (err) {
      setError("Unable to access the webcam. Please check your permissions.");
    }
  };

  const stopVideo = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject;
      const tracks = stream.getTracks();
      tracks.forEach((track) => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsStreaming(false);
  };

  return (
    <div style={styles.container}>
      <h1>Live Video Feed</h1>
      {error && <p style={styles.error}>{error}</p>}
      <video ref={videoRef} style={styles.video} autoPlay playsInline />
      <div>
        {!isStreaming ? (
          <button onClick={startVideo} style={styles.startButton}>
            Start Video
          </button>
        ) : (
          <button onClick={stopVideo} style={styles.stopButton}>
            Stop Video
          </button>
        )}
      </div>
    </div>
  );
};

const styles = {
  container: {
    textAlign: "center",
    fontFamily: "Arial, sans-serif",
    marginTop: "50px",
  },
  video: {
    width: "80%",
    maxWidth: "600px",
    border: "2px solid #333",
    borderRadius: "10px",
    margin: "20px 0",
  },
  startButton: {
    padding: "10px 20px",
    fontSize: "16px",
    color: "white",
    backgroundColor: "#4CAF50",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
  },
  stopButton: {
    padding: "10px 20px",
    fontSize: "16px",
    color: "white",
    backgroundColor: "#f44336",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
  },
  error: {
    color: "red",
    fontSize: "16px",
  },
};

export default LiveVideoFeed;
